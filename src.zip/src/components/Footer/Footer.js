import React from "react";
import footerStyle from "../Footer/footer.module.css";

const Footer = () => {
  return <div className={footerStyle.footer}> ©Nisha Saraswat 2021 </div>;
};
export default Footer;
